# import feedparser
# NewsFeed = feedparser.parse("https://www.argusmedia.com/en/news-rss-feed?type=rss")
# header = NewsFeed.entries[1]

# # print(entry.keys())

# for entry in NewsFeed.entries:
# 	print(entry)
# 	# for i in header:
# 	# 	print(i + ': ' + entry[i])
# # print(NewsFeed.entries)

# # print('Hi I am Abdullah')



import scrapy
from scrapy.http import FormRequest
import time
from scrapy.utils.response import open_in_browser
import pandas as pd 
from scrapy_splash import SplashRequest
import csv

class argus_news(scrapy.Spider):
    name = 'argus_news'
    
    start_urls = [
        'https://www.argusmedia.com'
    ]

    custom_settings = {
        'DUPEFILTER_CLASS': 'scrapy.dupefilters.BaseDupeFilter',
    }
        
    #Class valiable:
    courses_data = []
    current_index = 0

    def parse(self, response):
    	next_url = 'https://www.argusmedia.com/en/news/2320792-toy-producer-mattel-turns-to-renewable-plastics'
        yield SplashRequest(url=next_url, dont_filter=True, callback=self.read_news)


    def read_news(self, response):
        pass