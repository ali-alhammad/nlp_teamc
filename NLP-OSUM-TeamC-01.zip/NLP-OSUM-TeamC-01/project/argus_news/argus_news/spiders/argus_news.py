import scrapy
from scrapy_splash import SplashRequest
import csv
from w3lib.html import remove_tags
import feedparser
import pandas as pd

class argus_news(scrapy.Spider):
    #Mandatory arguments for scrapy: -----------------------------
    name = 'argus_news'
    
    start_urls = [
        'https://www.argusmedia.com'
    ]

    custom_settings = {
        'DUPEFILTER_CLASS': 'scrapy.dupefilters.BaseDupeFilter',
    }

    #Global veriables:---------------------------------------------
    articale_data_list = []
    incrimental_number = 0
    count_of_all_feeds = 0
    all_feeds = []
    current_url = ''

    #AUX Functions: ----------------------------------------------- 
    # Function to convert list to string 
    def list_to_string(self, s): 
        str1 = " " 
        return (str1.join(s))


    #Parcing functions: -------------------------------------------
    def parse(self, response):

        if self.incrimental_number == 0:
            #Download the RSS Feeds: from the subject website:
            website = "https://www.argusmedia.com/en/news-rss-feed?type=rss"
            news_feed = feedparser.parse(website)

            #Capture the count for the retrived RSS to set the maximum boundry for the scrapping functions:
            self.all_feeds = news_feed.entries#[0:5]
            self.count_of_all_feeds = len(self.all_feeds)

        #Scrap the following links that got retrived through the RSS:
        for i, single_feed in enumerate(self.all_feeds):
            next_url = single_feed['link']
            self.current_url = next_url
            yield SplashRequest(next_url, args={'wait': 3}, callback = self.read_news)


    def read_news(self, response):
        #Start scrapping data for a single page:
        page_title = response.css('div.news-container h1::text').extract_first()
        publish_date = response.css('div.news-container aside div.date p span::text').extract_first()
        article = response.css('div.news-container article p').extract()
        writer = None
        article_html = None 
        
        try:
            if str(article[-1])[0:19] == '<p class="bylines">':
                writer = article[-1]
                writer = remove_tags(str(writer))

                article = article[0:len(article)-1]
        except:
            pass

        article_text = remove_tags(str(self.list_to_string(article)))

        try:
            article_html = str(article)
        except:
            pass

        # articale_data = {   'title'         : str(page_title),
        #                     'publish_date'  : str(publish_date),
        #                     'writer'        : str(writer),
        #                     'artical'       : article_text,
        #                     'artical_html'  : article[0],
        #                     'url'           : response.request.url
        #              } 
        articale_data = [ str(page_title),
                          str(publish_date),
                          str(writer),
                          article_text,
                          article_html,
                          str(response.request._original_url)
                        ]     

        #Append the scrapped result to the overall scrapped articals:   
        self.articale_data_list.append(articale_data)

        #After finishing scraping all web pages, build the dataframe and export all the scrapped data as csv.
        if len(self.articale_data_list) == self.count_of_all_feeds:

            #Build the dataframe
            argusnews_df = pd.DataFrame(self.articale_data_list, columns=['title', 'publish_date','writer','artical','artical_html','url'])
            
            #export the result to csv file
            argusnews_df.to_csv('argusnews.csv', index=False)








# import scrapy
# # from scrapy.http import FormRequest
# # from scrapy.utils.response import open_in_browser
# # import pandas as pd 
# from scrapy_splash import SplashRequest
# import csv
# from w3lib.html import remove_tags
# import feedparser
# import pandas as pd

# class argus_news(scrapy.Spider):
#     name = 'argus_news'
    
#     start_urls = [
#         'https://www.argusmedia.com'
#     ]

#     custom_settings = {
#         'DUPEFILTER_CLASS': 'scrapy.dupefilters.BaseDupeFilter',
#     }

#     articale_data_f = {}
#     articale_data_l = []
#     webnews_df = pd.DataFrame(columns=['title', 'language','publish_date','writer','link','artical','artical_html'])
        
#     # Function to convert list to string 
#     def listToString(self, s): 
#         str1 = " " 
#         return (str1.join(s))


#     def parse(self, response):
#         #Download the RSS Feeds: from the subject website:
#         website = "https://www.argusmedia.com/en/news-rss-feed?type=rss"
#         news_feed = feedparser.parse(website)

#         #Process the downloaded feeds:
#         all_feeds = []
#         for single_feed in news_feed.entries:
#             self.articale_data_l = []

#             #Get artical data:
#             if single_feed['link'] is not None:
#                 print(' [1] -------')
#                 self.articale_data_f = yield SplashRequest(single_feed['link'], args={'wait': 2 , 'test': 'test'}, callback = self.read_news)

#             # print('articale_data -----------------------')
#             # print(self.articale_data_f)
#             # print('-------------------------------------')
#             entry = []
#             entry = [single_feed['title'], single_feed['title_detail']['language'], self.articale_data_l[1], self.articale_data_l[2], single_feed['link'], self.articale_data_l[3], self.articale_data_l[4]]
            
#             all_feeds.append(entry)

#         #Create a dataframe for all feeds:
#         webnews_df = pd.DataFrame(all_feeds, columns = ['title', 'language','publish_date','writer','link','artical','artical_html']) 
#         print('The result is:-------------------------')
#         print(webnews_df)


#         # next_url = 'https://www.argusmedia.com/en/news/2320792-toy-producer-mattel-turns-to-renewable-plastics'
#         # yield SplashRequest(next_url, callback = self.read_news)

#     def read_news(self, response, test):
#         print(' [2] -------' + test)
#         # print('response:---------')
#         # print(response)
#         page_title = response.css('div.news-container h1::text').extract_first()
#         publish_date = response.css('div.news-container aside div.date p span::text').extract_first()
#         article = response.css('div.news-container article p').extract()
#         writer = None

#         try:
#             if str(article[-1])[0:19] == '<p class="bylines">':
#                 writer = article[-1]
#                 writer = remove_tags(str(writer))

#                 article = article[0:len(article)-1]
#         except:
#             pass

#         article_text = remove_tags(str(self.listToString(article)))

#         articale_data = {   'title'         : str(page_title),
#                             'publish_date'  : str(publish_date),
#                             'writer'        : str(writer),
#                             'artical'       : article_text,
#                             'artical_html'  : article[0]
#                      }  
#         self.articale_data_l = [ str(page_title),
#                             str(publish_date),
#                             str(writer),
#                             article_text,
#                             article[0]  ]

#         # print(articale_data)
#         self.articale_data_f = articale_data
#         yield articale_data

#         # print('------------------')
#         # print('Title: ' + str(page_title))
#         # print('Publish Date: ' + str(publish_date))
#         # print('Writer: ' + str(writer))
#         # print('Artical: ')
#         # print(article_text)
#         # print('------------------')